import pygame as pg
from opciones import*
import os
import operator
import math

class Grupos():
    def __init__(self, game):
        self.game = game
        
        self.layer_0= pg.sprite.Group()      #Grupo a utilizar que no se ocupa
        self.layer_1= pg.sprite.Group()
        self.layer_2= pg.sprite.Group()
        self.layer_3= pg.sprite.Group()
        self.layer_4= pg.sprite.Group()
        self.layer_5= pg.sprite.Group()
        self.layer_6= pg.sprite.Group()
        self.layer_7= pg.sprite.Group()
        
        self.layers = [self.layer_0,
                       self.layer_1, 
                       self.layer_2, 
                       self.layer_3, 
                       self.layer_4,
                       self.layer_5,
                       self.layer_6,
                       self.layer_7]

    def dibujar(self,camara = False):
        for layer in self.layers:
            for sprite in layer:
                if camara:
                    self.game.pantalla.blit(sprite.image, self.game.camara.aplicar(sprite))
                else:
                    self.game.pantalla.blit(sprite.image, sprite.rect)
        
    def agregar(self,sprite,layer):
        self.layers[layer].add(sprite)
            
    def vaciar(self, layer=0):
        if layer == 0:
            for layer in self.layers:
                layer.empty()
        else:
            self.layers[layer].empty()
            
    def update(self):
        for layer in self.layers:
            layer.update()
            
            
class Animado():
    def iniciar(self, directorio):
        self.directorio = archivo(frame_dir, directorio)
        self.last_update = 0
        self.current_frame = 0
        self.cargar_frames()
        self.image = self.frames[0]
        self.rect = self.image.get_rect()
    def cargar_frames(self):      #hacer eso al cargar data
        self.frames = list()
        for aux in range(len(os.listdir(self.directorio))):   #probar aux en for
            aux +=1
            img = pg.image.load(archivo.format(self.directorio,str(aux)+'.jpeg'))
            img = pg.transform.scale(img,(300, 300))
            self.frames.append(img)
            
    def animar(self, tipo):
        now = pg.time.get_ticks()
        if now - self.last_update > ANI_FPS:
            self.last_update = now
            self.current_frame = (self.current_frame + 1)% len(self.frames)
            self.image = self.frames[self.current_frame]


class Jugador(pg.sprite.Sprite, Animado):
    def __init__(self,game,layer):
        pg.sprite.Sprite.__init__(self)
        game.grupos.agregar(self,layer)
        self.layer = layer
        self.game = game
        self.image = pg.Surface((30,30))
        self.image.fill(NEGRO)
        self.rect = self.image.get_rect()
        #self.iniciar('caminar')
        self.rect.center = (ANCHO/2, ALTO/2)
        self.pos = Vec(ANCHO/2, ALTO/2)
        self.acc = Vec(0,0)
        self.vel = Vec(0,0)
        
        
    def update(self):
        #self.animar(1)
        self.acc.x, self.acc.y = 0,0
        keys = pg.key.get_pressed()
        if keys[pg.K_LEFT]:
            self.acc.x = -PLAYER_ACC
        if keys[pg.K_RIGHT]:
            self.acc.x = PLAYER_ACC
        
        self.acc += self.vel * PLAYER_FRICTION
        self.vel += self.acc
        if abs(self.vel.x) < 0.1 :
            self.vel.x = 0
            
        self.pos += self.vel + (self.acc**2)/2

        if self.pos.x > ANCHO + self.rect.width/2:
            self.pos.x = ANCHO + self.rect.width/2
        if self.pos.x< 0- self.rect.width/2:
            self.pos.x = 0 - self.rect.width/2
        
        self.rect.center = self.pos
        
        
        
class Wall(pg.sprite.Sprite):
    def __init__(self, game, x, y, layer):
        self.groups = game.grupos.layers[layer]
        pg.sprite.Sprite.__init__(self, self.groups)
        self.layer = layer
        self.game = game
        self.image = pg.Surface((30,30))
        if self.layer == 1:
            self.image.fill((100,30,30))
        elif self.layer == 2:
            self.image.fill((150,0,0))
        else:
            self.image.fill((200,0,0))
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        self.rect.topleft = x*CUADRADO, y*CUADRADO
 


class Vec(object):
    """2d vector class, supports vector and scalar operators,
       and also provides a bunch of high level functions
       """
    __slots__ = ['x', 'y']
 
    def __init__(self, x_or_pair, y = None):
        if y == None:
            self.x = x_or_pair[0]
            self.y = x_or_pair[1]
        else:
            self.x = x_or_pair
            self.y = y
 
    def __len__(self):
        return 2
 
    def __getitem__(self, key):
        if key == 0:
            return self.x
        elif key == 1:
            return self.y
        else:
            raise IndexError("Invalid subscript "+str(key)+" to Vec")
 
    def __setitem__(self, key, value):
        if key == 0:
            self.x = value
        elif key == 1:
            self.y = value
        else:
            raise IndexError("Invalid subscript "+str(key)+" to Vec")
 
    # String representaion (for debugging)
    def __repr__(self):
        return 'Vec(%s, %s)' % (self.x, self.y)
 
    # Comparison
    def __eq__(self, other):
        if hasattr(other, "__getitem__") and len(other) == 2:
            return self.x == other[0] and self.y == other[1]
        else:
            return False
 
    def __ne__(self, other):
        if hasattr(other, "__getitem__") and len(other) == 2:
            return self.x != other[0] or self.y != other[1]
        else:
            return True
 
    def __nonzero__(self):
        return bool(self.x or self.y)
 
    # Generic operator handlers
    def _o2(self, other, f):
        "Any two-operator operation where the left operand is a Vec"
        if isinstance(other, Vec):
            return Vec(f(self.x, other.x),
                         f(self.y, other.y))
        elif (hasattr(other, "__getitem__")):
            return Vec(f(self.x, other[0]),
                         f(self.y, other[1]))
        else:
            return Vec(f(self.x, other),
                         f(self.y, other))
 
    def _r_o2(self, other, f):
        "Any two-operator operation where the right operand is a Vec"
        if (hasattr(other, "__getitem__")):
            return Vec(f(other[0], self.x),
                         f(other[1], self.y))
        else:
            return Vec(f(other, self.x),
                         f(other, self.y))
 
    def _io(self, other, f):
        "inplace operator"
        if (hasattr(other, "__getitem__")):
            self.x = f(self.x, other[0])
            self.y = f(self.y, other[1])
        else:
            self.x = f(self.x, other)
            self.y = f(self.y, other)
        return self
 
    # Addition
    def __add__(self, other):
        if isinstance(other, Vec):
            return Vec(self.x + other.x, self.y + other.y)
        elif hasattr(other, "__getitem__"):
            return Vec(self.x + other[0], self.y + other[1])
        else:
            return Vec(self.x + other, self.y + other)
    __radd__ = __add__
 
    def __iadd__(self, other):
        if isinstance(other, Vec):
            self.x += other.x
            self.y += other.y
        elif hasattr(other, "__getitem__"):
            self.x += other[0]
            self.y += other[1]
        else:
            self.x += other
            self.y += other
        return self
 
    # Subtraction
    def __sub__(self, other):
        if isinstance(other, Vec):
            return Vec(self.x - other.x, self.y - other.y)
        elif (hasattr(other, "__getitem__")):
            return Vec(self.x - other[0], self.y - other[1])
        else:
            return Vec(self.x - other, self.y - other)
    def __rsub__(self, other):
        if isinstance(other, Vec):
            return Vec(other.x - self.x, other.y - self.y)
        if (hasattr(other, "__getitem__")):
            return Vec(other[0] - self.x, other[1] - self.y)
        else:
            return Vec(other - self.x, other - self.y)
    def __isub__(self, other):
        if isinstance(other, Vec):
            self.x -= other.x
            self.y -= other.y
        elif (hasattr(other, "__getitem__")):
            self.x -= other[0]
            self.y -= other[1]
        else:
            self.x -= other
            self.y -= other
        return self
 
    # Multiplication
    def __mul__(self, other):
        if isinstance(other, Vec):
            return Vec(self.x*other.x, self.y*other.y)
        if (hasattr(other, "__getitem__")):
            return Vec(self.x*other[0], self.y*other[1])
        else:
            return Vec(self.x*other, self.y*other)
    __rmul__ = __mul__
 
    def __imul__(self, other):
        if isinstance(other, Vec):
            self.x *= other.x
            self.y *= other.y
        elif (hasattr(other, "__getitem__")):
            self.x *= other[0]
            self.y *= other[1]
        else:
            self.x *= other
            self.y *= other
        return self
 
    # Division
    def __div__(self, other):
        return self._o2(other, operator.div)
    def __rdiv__(self, other):
        return self._r_o2(other, operator.div)
    def __idiv__(self, other):
        return self._io(other, operator.div)
 
    def __floordiv__(self, other):
        return self._o2(other, operator.floordiv)
    def __rfloordiv__(self, other):
        return self._r_o2(other, operator.floordiv)
    def __ifloordiv__(self, other):
        return self._io(other, operator.floordiv)
 
    def __truediv__(self, other):
        return self._o2(other, operator.truediv)
    def __rtruediv__(self, other):
        return self._r_o2(other, operator.truediv)
    def __itruediv__(self, other):
        return self._io(other, operator.floordiv)
 
    # Modulo
    def __mod__(self, other):
        return self._o2(other, operator.mod)
    def __rmod__(self, other):
        return self._r_o2(other, operator.mod)
 
    def __divmod__(self, other):
        return self._o2(other, operator.divmod)
    def __rdivmod__(self, other):
        return self._r_o2(other, operator.divmod)
 
    # Exponentation
    def __pow__(self, other):
        return self._o2(other, operator.pow)
    def __rpow__(self, other):
        return self._r_o2(other, operator.pow)
 
    # Bitwise operators
    def __lshift__(self, other):
        return self._o2(other, operator.lshift)
    def __rlshift__(self, other):
        return self._r_o2(other, operator.lshift)
 
    def __rshift__(self, other):
        return self._o2(other, operator.rshift)
    def __rrshift__(self, other):
        return self._r_o2(other, operator.rshift)
 
    def __and__(self, other):
        return self._o2(other, operator.and_)
    __rand__ = __and__
 
    def __or__(self, other):
        return self._o2(other, operator.or_)
    __ror__ = __or__
 
    def __xor__(self, other):
        return self._o2(other, operator.xor)
    __rxor__ = __xor__
 
    # Unary operations
    def __neg__(self):
        return Vec(operator.neg(self.x), operator.neg(self.y))
 
    def __pos__(self):
        return Vec(operator.pos(self.x), operator.pos(self.y))
 
    def __abs__(self):
        return Vec(abs(self.x), abs(self.y))
 
    def __invert__(self):
        return Vec(-self.x, -self.y)
 
    # vectory functions
    def get_length_sqrd(self):
        return self.x**2 + self.y**2
 
    def get_length(self):
        return math.sqrt(self.x**2 + self.y**2)
    def __setlength(self, value):
        length = self.get_length()
        self.x *= value/length
        self.y *= value/length
    length = property(get_length, __setlength, None, "gets or sets the magnitude of the vector")
 
    def rotate(self, angle_degrees):
        radians = math.radians(angle_degrees)
        cos = math.cos(radians)
        sin = math.sin(radians)
        x = self.x*cos - self.y*sin
        y = self.x*sin + self.y*cos
        self.x = x
        self.y = y
 
    def rotated(self, angle_degrees):
        radians = math.radians(angle_degrees)
        cos = math.cos(radians)
        sin = math.sin(radians)
        x = self.x*cos - self.y*sin
        y = self.x*sin + self.y*cos
        return Vec(x, y)
 
    def get_angle(self):
        if (self.get_length_sqrd() == 0):
            return 0
        return math.degrees(math.atan2(self.y, self.x))
    def __setangle(self, angle_degrees):
        self.x = self.length
        self.y = 0
        self.rotate(angle_degrees)
    angle = property(get_angle, __setangle, None, "gets or sets the angle of a vector")
 
    def get_angle_between(self, other):
        cross = self.x*other[1] - self.y*other[0]
        dot = self.x*other[0] + self.y*other[1]
        return math.degrees(math.atan2(cross, dot))
 
    def normalized(self):
        length = self.length
        if length != 0:
            return self/length
        return Vec(self)
 
    def normalize_return_length(self):
        length = self.length
        if length != 0:
            self.x /= length
            self.y /= length
        return length
 
    def perpendicular(self):
        return Vec(-self.y, self.x)
 
    def perpendicular_normal(self):
        length = self.length
        if length != 0:
            return Vec(-self.y/length, self.x/length)
        return Vec(self)
 
    def dot(self, other):
        return float(self.x*other[0] + self.y*other[1])
 
    def get_distance(self, other):
        return math.sqrt((self.x - other[0])**2 + (self.y - other[1])**2)
 
    def get_dist_sqrd(self, other):
        return (self.x - other[0])**2 + (self.y - other[1])**2
 
    def projection(self, other):
        other_length_sqrd = other[0]*other[0] + other[1]*other[1]
        projected_length_times_other_length = self.dot(other)
        return other*(projected_length_times_other_length/other_length_sqrd)
 
    def cross(self, other):
        return self.x*other[1] - self.y*other[0]
 
    def interpolate_to(self, other, range):
        return Vec(self.x + (other[0] - self.x)*range, self.y + (other[1] - self.y)*range)
 
    def convert_to_basis(self, x_vector, y_vector):
        return Vec(self.dot(x_vector)/x_vector.get_length_sqrd(), self.dot(y_vector)/y_vector.get_length_sqrd())
 
    def __getstate__(self):
        return [self.x, self.y]
 
    def __setstate__(self, dict):
        self.x, self.y = dict
